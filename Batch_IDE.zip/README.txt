Batch Editor
-------------

1) Introduction

Batch IDE is a free batch scripting utitlity for windows. Batch IDE makes it easy to work with windows batch files. it has a useful yet simple interface for users who want simplicity with functionality.
With Batch IDE, you can create, edit, modify and debug batch files easily without using the manual methos for these tasks. 
----------
Why another program for editing batch files?

When i first started to learn batch, i used the standard text editing tool windows notepad for creating and editing batch files, and i felt the need of a program which i can use to simplify my work with batch files. When i mastered batch scripting, i learned object-oriented computer programming language. i realized that it was fairly easy to create a basic batch-scripter using VB. i started to look for an existing solution for the task but i was not able to find anything; After that i decided to develop my own scripter for batch scripting. and that's how "Batch IDE" was born.


2) Help

NOTE: This is BETA version of the program. so it may contain some bugs. 
if you need any help please contact author.

If you want to contribute to Batch IDE then visit GitHub for further instructions.
BY USING THIS PROGRAM, YOU AGREE TO THE LICENSE TERMS DESCRIBED IN 
THE LICENSE DOCUMENT.

Programmed and designed by: schatz
e-mail: schatzworks@gmail.com 

