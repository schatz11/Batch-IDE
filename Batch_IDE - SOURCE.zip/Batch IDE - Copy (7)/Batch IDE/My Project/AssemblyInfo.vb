﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Batch IDE")> 
<Assembly: AssemblyDescription("A simple batch editor for windows")> 
<Assembly: AssemblyCompany("schatz")> 
<Assembly: AssemblyProduct("Batch IDE")> 
<Assembly: AssemblyCopyright("Copyright ©  2017 schatz")> 
<Assembly: AssemblyTrademark("Batch IDE")> 

<Assembly: ComVisible(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("6f1fc064-cd47-4d2d-8c4d-70dbc8e670b8")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.1.0")> 
<Assembly: AssemblyFileVersion("1.0.2.3")> 
