﻿Imports System
Public Class form_main
    Dim dragdropfile As String
    Dim currentfile As Boolean = False
    Dim currentfpath As String
    Dim fileloc As String = "temp1.bat"
    Dim p() As Process
    Dim fpath As New OpenFileDialog
    Dim cmdlist = My.Settings.editorfont

   
    Private Sub form_main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'checks for the folder
     
        'changes menustrip's font color 
        MenuStrip1.ForeColor = Color.White

        'changes textbox's back color to dark
        Panel1.BackColor = Color.FromArgb(45, 45, 54)
        MenuStrip1.BackColor = Color.FromArgb(45, 45, 54)
        Me.BackColor = Color.FromArgb(37, 37, 39)
        'determines if the RUN function can be performed or not by using textbox status
        If TextBox1.Text.Length = 0 = True Then
            RunToolStripMenuItem.Enabled = False
        Else
            RunToolStripMenuItem.Enabled = True
        End If
        TextBox1.BackColor = Color.FromArgb(28, 28, 28)
        ContextMenuStrip1.ForeColor = Color.DarkGray
    End Sub

    Private Sub TextBox1_DragDrop(sender As Object, e As DragEventArgs)
        'gets file from dragdrop
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
        For Each path In files
            currentfpath = path
        Next
    End Sub

    Private Sub TextBox1_DragEnter(sender As Object, e As DragEventArgs)
        'SHow a msgbox before opening the file 
        If TextBox1.Modified = True Then

            Dim x1 As Integer = MsgBox("Do you want to save the modified document ?", MsgBoxStyle.YesNo)
            'Know if the yes is clicked
            If x1 = vbYes Then
                SaveToolStripMenuItem.PerformClick()
                If e.Data.GetDataPresent(DataFormats.FileDrop) Then
                    Dim MyFiles() As String
                    ' Assign the files to an array.
                    MyFiles = e.Data.GetData(DataFormats.FileDrop)
                    ' Display the file Name
                    'TextBoxDrop.Text = MyFiles(0)
                    ' Display the file contents
                    TextBox1.Text = My.Computer.FileSystem.ReadAllText(MyFiles(0))
                    dragdropfile = (MyFiles(0))
                End If
            End If
        Else
            If e.Data.GetDataPresent(DataFormats.FileDrop) Then
                Dim MyFiles() As String
                ' Assign the files to an array.
                MyFiles = e.Data.GetData(DataFormats.FileDrop)
                ' Display the file Name
                'TextBoxDrop.Text = MyFiles(0)
                ' Display the file contents
                TextBox1.Text = My.Computer.FileSystem.ReadAllText(MyFiles(0))
                dragdropfile = (MyFiles(0))
            End If
        End If
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        'Knows if the text is modified, if it has been modified then asks to save or not 
        'Knows if the text is modified, if it has been modified then asks to save or not 
        If TextBox1.Modified = True Then

            If Not TextBox1.Text.Length = 0 Then
                Dim x As Integer = MsgBox("Do you want to save the modified document ?", MsgBoxStyle.YesNo)
                If x = vbYes Then
                    SaveToolStripMenuItem.PerformClick()
                    If Not OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.Cancel Then
                        If IO.File.Exists(OpenFileDialog1.FileName) = True Then
                            Using tr As IO.TextReader = New IO.StreamReader(OpenFileDialog1.FileName)
                                TextBox1.Text = (tr.ReadToEnd)
                                currentfile = True
                                currentfpath = OpenFileDialog1.FileName
                                label_filetitles.Text = OpenFileDialog1.SafeFileName
                            End Using
                        End If
                    Else

                    End If
                Else
                    If Not OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.Cancel Then
                        If IO.File.Exists(OpenFileDialog1.FileName) = True Then
                            Using tr As IO.TextReader = New IO.StreamReader(OpenFileDialog1.FileName)
                                TextBox1.Text = (tr.ReadToEnd)
                                currentfile = True
                                currentfpath = OpenFileDialog1.FileName
                                label_filetitles.Text = OpenFileDialog1.SafeFileName
                            End Using
                        End If
                    Else
                    End If
                End If



            End If
        Else
            If Not OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.Cancel Then
                If IO.File.Exists(OpenFileDialog1.FileName) = True Then
                    Using tr As IO.TextReader = New IO.StreamReader(OpenFileDialog1.FileName)
                        TextBox1.Text = (tr.ReadToEnd)
                        Me.Text = (OpenFileDialog1.SafeFileName & "- Batch IDE")
                        currentfile = True
                        currentfpath = OpenFileDialog1.FileName
                        label_filetitles.Text = OpenFileDialog1.SafeFileName
                    End Using
                Else
                    MsgBox("file doesn't exist")
                End If
            End If
        End If


        'reads the file

    End Sub

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        If currentfile = True Then
            Dim fs As IO.FileStream
            fs = IO.File.Create(currentfpath)
            Using fs

            End Using

            Using sw As IO.StreamWriter = New IO.StreamWriter(currentfpath)
                sw.Write(TextBox1.Text)
                fpath.FileName = currentfpath
                label_filetitles.Text = fpath.SafeFileName
            End Using
        Else
            If Not SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.Cancel Then
                Dim fs As IO.FileStream
                fs = IO.File.Create(SaveFileDialog1.FileName)
                Using fs

                End Using

                Using sw As IO.StreamWriter = New IO.StreamWriter(SaveFileDialog1.FileName)
                    sw.Write(TextBox1.Text)
                    currentfile = True
                    currentfpath = SaveFileDialog1.FileName
                    fpath.FileName = currentfpath
                    label_filetitles.Text = fpath.SafeFileName
                End Using
            Else
            End If
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        If Not SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.Cancel Then
            Dim fs As IO.FileStream
            fs = IO.File.Create(SaveFileDialog1.FileName)
            Using fs

            End Using

            Using sw As IO.StreamWriter = New IO.StreamWriter(SaveFileDialog1.FileName)
                sw.Write(TextBox1.Text)
                fpath.FileName = currentfpath
                label_filetitles.Text = fpath.SafeFileName
            End Using
        Else
        End If
    End Sub

    Private Sub NewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewToolStripMenuItem.Click
        If Not TextBox1.Modified = True Then
            label_filetitles.Text = "Untitled - Batch IDE"
            TextBox1.Clear()
        Else

            If Not TextBox1.Text.Length = (0) = True Then
                Dim x As Integer = MsgBox("Do you want to save the modified document ?", MsgBoxStyle.YesNo)
                If x = vbYes Then
                    SaveToolStripMenuItem.PerformClick()
                Else
                    TextBox1.Clear()
                    label_filetitles.Text = "Untitled"
                End If
            End If



        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub RunToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RunToolStripMenuItem.Click

        Dim fs As IO.FileStream = Nothing

        fs = IO.File.Create(fileloc)
        Using fs

        End Using
        If IO.File.Exists(fileloc) Then
            Using sw As IO.StreamWriter = New IO.StreamWriter(fileloc)
                sw.Write(TextBox1.Text)
            End Using
        End If

        Process.Start(fileloc)
        StopToolStripMenuItem.Enabled = True


    End Sub

    Private Sub StopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StopToolStripMenuItem.Click
        p = Process.GetProcessesByName("cmd.exe")
        If p.Length > 0 Then
            Kill(fileloc)
            StopToolStripMenuItem.Enabled = False
        Else

        End If
    End Sub
    

#Region "Drag"

    Dim posX As Integer
    Dim posY As Integer
    Dim drag As Boolean

    Private Sub panel1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel1.MouseDoubleClick
        If e.Button = MouseButtons.Left Then
            If maximized Then
                Me.WindowState = FormWindowState.Normal
                maximized = False
            Else
                Me.WindowState = FormWindowState.Maximized
                maximized = True
            End If
        End If
    End Sub

    Private Sub panel1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel1.MouseDown
        If e.Button = MouseButtons.Left Then
            drag = True
            posX = Cursor.Position.X - Me.Left
            posY = Cursor.Position.Y - Me.Top
        End If
    End Sub

    Private Sub panel1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel1.MouseUp
        drag = False
    End Sub

    Private Sub panel1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel1.MouseMove
        If drag Then
            Me.Top = Cursor.Position.Y - posY
            Me.Left = Cursor.Position.X - posX
        End If
        Me.Cursor = Cursors.Default
    End Sub

    Private Sub buttonMin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonMin.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub buttonClos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonClose.Click
        Me.Close()
    End Sub

    Private Sub buttonMax_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttonMax.Click
        If maximized Then
            maximized = False
            Me.WindowState = FormWindowState.Normal
        Else
            maximized = True
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub

#End Region

#Region "Resize"

    Dim onFullScreen As Boolean
    Dim maximized As Boolean
    Dim on_MinimumSize As Boolean
    Dim minimumWidth As Short = 350
    Dim minimumHeight As Short = 26
    Dim borderSpace As Short = 20
    Dim borderDiameter As Short = 3

    Dim onBorderRight As Boolean
    Dim onBorderLeft As Boolean
    Dim onBorderTop As Boolean
    Dim onBorderBottom As Boolean
    Dim onCornerTopRight As Boolean
    Dim onCornerTopLeft As Boolean
    Dim onCornerBottomRight As Boolean
    Dim onCornerBottomLeft As Boolean

    Dim movingRight As Boolean
    Dim movingLeft As Boolean
    Dim movingTop As Boolean
    Dim movingBottom As Boolean
    Dim movingCornerTopRight As Boolean
    Dim movingCornerTopLeft As Boolean
    Dim movingCornerBottomRight As Boolean
    Dim movingCornerBottomLeft As Boolean

    Private Sub Borderless_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            If onBorderRight Then movingRight = True Else movingRight = False
            If onBorderLeft Then movingLeft = True Else movingLeft = False
            If onBorderTop Then movingTop = True Else movingTop = False
            If onBorderBottom Then movingBottom = True Else movingBottom = False
            If onCornerTopRight Then movingCornerTopRight = True Else movingCornerTopRight = False
            If onCornerTopLeft Then movingCornerTopLeft = True Else movingCornerTopLeft = False
            If onCornerBottomRight Then movingCornerBottomRight = True Else movingCornerBottomRight = False
            If onCornerBottomLeft Then movingCornerBottomLeft = True Else movingCornerBottomLeft = False
        End If
    End Sub

    Private Sub Borderless_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseUp
        stopResizer()
    End Sub

    Private Sub Borderless_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseMove
        If onFullScreen Or maximized Then Exit Sub

        If Me.Width <= minimumWidth Then Me.Width = (minimumWidth + 5) : on_MinimumSize = True
        If Me.Height <= minimumHeight Then Me.Height = (minimumHeight + 5) : on_MinimumSize = True
        If on_MinimumSize Then stopResizer() Else startResizer()


        If (Cursor.Position.X > (Me.Location.X + Me.Width) - borderDiameter) _
            And (Cursor.Position.Y > (Me.Location.Y + borderSpace)) _
            And (Cursor.Position.Y < ((Me.Location.Y + Me.Height) - borderSpace)) Then
            Me.Cursor = Cursors.SizeWE
            onBorderRight = True

        ElseIf (Cursor.Position.X < (Me.Location.X + borderDiameter)) _
            And (Cursor.Position.Y > (Me.Location.Y + borderSpace)) _
            And (Cursor.Position.Y < ((Me.Location.Y + Me.Height) - borderSpace)) Then
            Me.Cursor = Cursors.SizeWE
            onBorderLeft = True

        ElseIf (Cursor.Position.Y < (Me.Location.Y + borderDiameter)) _
            And (Cursor.Position.X > (Me.Location.X + borderSpace)) _
            And (Cursor.Position.X < ((Me.Location.X + Me.Width) - borderSpace)) Then
            Me.Cursor = Cursors.SizeNS
            onBorderTop = True

        ElseIf (Cursor.Position.Y > ((Me.Location.Y + Me.Height) - borderDiameter)) _
            And (Cursor.Position.X > (Me.Location.X + borderSpace)) _
            And (Cursor.Position.X < ((Me.Location.X + Me.Width) - borderSpace)) Then
            Me.Cursor = Cursors.SizeNS
            onBorderBottom = True

        ElseIf (Cursor.Position.X = ((Me.Location.X + Me.Width) - 1)) _
            And (Cursor.Position.Y = Me.Location.Y) Then
            Me.Cursor = Cursors.SizeNESW
            onCornerTopRight = True

        ElseIf (Cursor.Position.X = Me.Location.X) _
            And (Cursor.Position.Y = Me.Location.Y) Then
            Me.Cursor = Cursors.SizeNWSE
            onCornerTopLeft = True

        ElseIf (Cursor.Position.X = ((Me.Location.X + Me.Width) - 1)) _
            And (Cursor.Position.Y = ((Me.Location.Y + Me.Height) - 1)) Then
            Me.Cursor = Cursors.SizeNWSE
            onCornerBottomRight = True

        ElseIf (Cursor.Position.X = Me.Location.X) _
            And (Cursor.Position.Y = ((Me.Location.Y + Me.Height) - 1)) Then
            Me.Cursor = Cursors.SizeNESW
            onCornerBottomLeft = True

        Else
            onBorderRight = False
            onBorderLeft = False
            onBorderTop = False
            onBorderBottom = False
            onCornerTopRight = False
            onCornerTopLeft = False
            onCornerBottomRight = False
            onCornerBottomLeft = False
            Me.Cursor = Cursors.Default
        End If
    End Sub

    Private Sub startResizer()
        Select Case True

            Case movingRight
                Me.Width = (Cursor.Position.X - Me.Location.X)

            Case movingLeft
                Me.Width = ((Me.Width + Me.Location.X) - Cursor.Position.X)
                Me.Location = New Point(Cursor.Position.X, Me.Location.Y)

            Case movingTop
                Me.Height = ((Me.Height + Me.Location.Y) - Cursor.Position.Y)
                Me.Location = New Point(Me.Location.X, Cursor.Position.Y)

            Case movingBottom
                Me.Height = (Cursor.Position.Y - Me.Location.Y)

            Case movingCornerTopRight
                Me.Width = (Cursor.Position.X - Me.Location.X)
                Me.Height = ((Me.Location.Y - Cursor.Position.Y) + Me.Height)
                Me.Location = New Point(Me.Location.X, Cursor.Position.Y)

            Case movingCornerTopLeft
                Me.Width = ((Me.Width + Me.Location.X) - Cursor.Position.X)
                Me.Location = New Point(Cursor.Position.X, Me.Location.Y)
                Me.Height = ((Me.Height + Me.Location.Y) - Cursor.Position.Y)
                Me.Location = New Point(Me.Location.X, Cursor.Position.Y)

            Case movingCornerBottomRight
                Me.Size = New Point((Cursor.Position.X - Me.Location.X), (Cursor.Position.Y - Me.Location.Y))

            Case movingCornerBottomLeft
                Me.Width = ((Me.Width + Me.Location.X) - Cursor.Position.X)
                Me.Height = (Cursor.Position.Y - Me.Location.Y)
                Me.Location = New Point(Cursor.Position.X, Me.Location.Y)

        End Select
    End Sub

    Private Sub stopResizer()
        movingRight = False
        movingLeft = False
        movingTop = False
        movingBottom = False
        movingCornerTopRight = False
        movingCornerTopLeft = False
        movingCornerBottomRight = False
        movingCornerBottomLeft = False
        Me.Cursor = Cursors.Default
        Threading.Thread.Sleep(300)
        on_MinimumSize = False
    End Sub
#End Region

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        panel1.Width = Me.Width - 6
        panel1.Location = New Point(3, 3)
        buttonClose.Location = New Point(Panel1.Width - 23, 3)
        buttonMax.Location = New Point(panel1.Width - 43, 3)
        buttonMin.Location = New Point(panel1.Width - 63, 3)
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Panel1.BackColor = Color.FromArgb(45, 45, 54)
        Me.BackColor = Color.FromArgb(37, 37, 39)
    End Sub


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        If TextBox1.Text.Length = 0 = True Then
            RunToolStripMenuItem.Enabled = False
        Else
            RunToolStripMenuItem.Enabled = True
        End If

        Dim words As New List(Of String)
        Dim wor1 As New List(Of String)

        words.Add("Select")
        words.Add("Insert")
        words.Add("ACINIUPD")
        words.Add("ANSI.SYS")
        words.Add("APPEND")
        words.Add("DPATH")
        words.Add("ASSOC")
        words.Add("ARP")
        words.Add("@")
        words.Add("ATTRIB")
        words.Add("AUTOFAIL")
        words.Add("BACKUP ")
        words.Add("BASICA")
        words.Add("BCDEDIT")
        words.Add("BOOTCFG")
        words.Add("BREAK")
        words.Add("CAClc")
        words.Add("set")
        words.Add("CALL")
        words.Add("Run ")
        words.Add("CD")
        words.Add("CDBURN")
        words.Add("CERTREQ")
        words.Add("CERTUTIL")
        words.Add("CHANGE ")
        words.Add("CHCP")
        words.Add("ChDir")
        words.Add("CHGLOGON")
        words.Add("CHGPORT")
        words.Add("CHGUSR")
        words.Add("CHKDSK")
        words.Add("CHKNTFS")
        words.Add("CHOICE")
        words.Add("Prompt")
        words.Add("CIPHER")
        words.Add("CLEANMGR")
        words.Add("CLS")
        words.Add("CMD.EXE")
        words.Add("CMDKEY")
        words.Add("Color")
        words.Add("color in")
        words.Add("Command.COM")
        words.Add("COMP")
        words.Add("COMPACT")
        words.Add("Control")
        words.Add("Start")
        words.Add("Convert")
        words.Add("COPY ")
        words.Add("CPROFILE")
        words.Add("CSCRIPT")
        words.Add("CSVDE")
        words.Add("CTTY")
        words.Add("DATE ")
        words.Add("DEBUG")
        words.Add("DEFRAG")
        words.Add("DEL ")
        words.Add("DELTREE")
        words.Add("DEVCON")
        words.Add("DHCPLOC")
        words.Add("DIANTZ")
        words.Add("Dir")
        words.Add("DISKCOMP")
        words.Add("DISKCOPY")
        words.Add("DISKPART")
        words.Add("DOSKEY")
        words.Add("DPATH")
        words.Add("DRIVERQUERY")
        words.Add("DSADD")
        words.Add("DSGET")
        words.Add("DSMOD")
        words.Add("DSMOVE")
        words.Add("DSQUERY")
        words.Add("DSRM")
        words.Add("DVDBURN")
        words.Add("ECHO")
        words.Add("EDIT")
        words.Add("EDLIN")
        words.Add("ENDLOCAL")
        words.Add("EPAL")
        words.Add("ERASE")
        words.Add("EVENTCREATE")
        words.Add("EVENTQUERY.VBS")
        words.Add("EVENTTRIGGERS")
        words.Add("EXIT ")
        words.Add("EXPAND")
        words.Add("EXPLORER")
        words.Add("EXTRACT")
        words.Add("EXE2BIN")
        words.Add("FASTOPEN")
        words.Add("FC")
        words.Add("FDISK")
        words.Add("FILEVER")
        words.Add("FIND ")
        words.Add("FINDRAMD")
        words.Add("FINDSTR")
        words.Add("FOR ")
        words.Add("FORCEDOS")
        words.Add("FORFILES")
        words.Add("Format ")
        words.Add("FSUTIL")
        words.Add("FTP")
        words.Add("FTYPE")
        words.Add("GETMAC")
        words.Add("GETTYPE")
        words.Add("GOTO ")
        words.Add("GPRESULT")
        words.Add("GRAFTABL")
        words.Add("GWBASIC")
        words.Add("Help ")
        words.Add("ICACLS")
        words.Add("IEXPRESS")
        words.Add("IF ")
        words.Add("IFCONFIG")
        words.Add("INUSE")
        words.Add("IPCONFIG")
        words.Add("JT")
        words.Add("Label")
        words.Add("LFNFOR")
        words.Add("LH")
        words.Add("LOADHIGH")
        words.Add("Lock ")
        words.Add("LOGMAN")
        words.Add("LOGOGG")
        words.Add("MAKECAB")
        words.Add("MD ")
        words.Add("MEM ")
        words.Add("MkDir")
        words.Add("MKLINK")
        words.Add("MODE ")
        words.Add("MORE ")
        words.Add("MOUNTVOL")
        words.Add("Move")
        words.Add("MSD")
        words.Add("MSG")
        words.Add("MSIEXEC")
        words.Add("MSINFO32")
        words.Add("NBTSTAT")
        words.Add("Net ")
        words.Add("NETDOM")
        words.Add("NETSH")
        words.Add("NETSTAT")
        words.Add("NLTEST")
        words.Add("NOTEPAD")
        words.Add("NSLOOKUP")
        words.Add("NTBACKUP")
        words.Add("OCSETUP")
        words.Add("ODBCCONF")
        words.Add("OPENFILES")
        words.Add("OFF ")
        words.Add("PATH")
        words.Add("PATHPING")
        words.Add("PAUSE")
        words.Add("PENTNT")
        words.Add("PING")
        words.Add("PING6")
        words.Add("PKGMGR")
        words.Add("POPD")
        words.Add("POWERCFG")
        words.Add("Print")
        words.Add("PRINTUI.EXE")
        words.Add("PRNCFG.VBS")
        words.Add("PRNDRVR.VBS")
        words.Add("PRNJOBS.VBS")
        words.Add("PRNMNGR.VBS")
        words.Add("PRNPORT.VBS")
        words.Add("PRNQCTL.VBS")
        words.Add("PROMPT")
        words.Add("PUBPRN.VBS")
        words.Add("PUSHD")
        words.Add("QAPPSRV")
        words.Add("QBASIC")
        words.Add("QCHAIN")
        words.Add("QFARM")
        words.Add("QPROCESS")
        words.Add("QSERVER")
        words.Add("QUERY")
        words.Add("QUSER")
        words.Add("QWINSTA")
        words.Add("RASDIAL")
        words.Add("RASPHONE")
        words.Add("RD ")
        words.Add("READLINE")
        words.Add("RECIMG")
        words.Add("RECOVER")
        words.Add("REG ")
        words.Add("REGEDIT")
        words.Add("REGEDT32")
        words.Add("REGINI")
        words.Add("REGSVR32")
        words.Add("REM")
        words.Add("REN")
        words.Add("Rename ")
        words.Add("Replace ")
        words.Add("Reset ")
        words.Add("RESTORE")
        words.Add("RmDir")
        words.Add("ROBOCOPY")
        words.Add("ROUTE")
        words.Add("RUNAS")
        words.Add("RUNDLL")
        words.Add("RUNDLL32")
        words.Add("SC ")
        words.Add("SCHTASKS")
        words.Add("SECEDIT")
        words.Add("SET")
        words.Add("SETLOCAL")
        words.Add("SFC")
        words.Add("SHADOW")
        words.Add("Shell ")
        words.Add("SHIFT")
        words.Add("SHUTDOWN")
        words.Add("SORT")
        words.Add("START")
        words.Add("SUBINACL")
        words.Add("SUBST")
        words.Add("SYSTEMINFO")
        words.Add("TASKKILL")
        words.Add("TASKLIST")
        words.Add("TIME")
        words.Add("TITLE")
        words.Add("TRACERT")
        words.Add("TRACERT6")
        words.Add("TRACERTE")
        words.Add("TREE")
        words.Add("TRUENAME")
        words.Add("TSCON")
        words.Add("TSDISCON")
        words.Add("TSKILL")
        words.Add("TSPROF")
        words.Add("TSSHUTDN")
        words.Add("Type")
        words.Add("TZCHANGE")
        words.Add("Unlock")
        words.Add("VER")
        words.Add("VERIFY")
        words.Add("VHDMOUNT")
        words.Add("VOL")
        words.Add("WINMSD")
        words.Add("WINMSDP")
        words.Add("WINSAT")
        words.Add("WMIC")
        words.Add("WSCRIPT")
        words.Add("WUPDMGR")
        words.Add("XCACLS")
        words.Add("XCOPY")
        If TextBox1.Text.Length > 0 Then

            Dim selectStart As Integer = TextBox1.SelectionStart

            TextBox1.Select(0, TextBox1.Text.Length)

            TextBox1.SelectionColor = Color.White

            TextBox1.DeselectAll()

            For Each oneWord As String In words

                Dim pos As Integer = 0

                Do While TextBox1.Text.ToUpper.IndexOf(oneWord.ToUpper, pos) >= 0

                    pos = TextBox1.Text.ToUpper.IndexOf(oneWord.ToUpper, pos)

                    TextBox1.Select(pos, oneWord.Length)

                    TextBox1.SelectionColor = Color.DeepSkyBlue

                    pos += 1

                Loop

            Next



            TextBox1.SelectionStart = selectStart

        End If
    End Sub

    Private Sub UndoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UndoToolStripMenuItem.Click
        If TextBox1.CanUndo = True Then
            TextBox1.Undo()
        End If
    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click
        TextBox1.Cut()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click
        TextBox1.Paste()
    End Sub

    Private Sub DelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DelToolStripMenuItem.Click

            TextBox1.Clear()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectAllToolStripMenuItem.Click
        TextBox1.SelectAll()
    End Sub

    Private Sub FindToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FindToolStripMenuItem.Click
        Dim a As String
        Dim b As String

        a = InputBox("Enter text to be found")
        b = InStr(TextBox1.Text, a)

        If b Then

            TextBox1.Focus()
            TextBox1.SelectionStart = b - 1
            TextBox1.SelectionLength = Len(a)
        Else
            MsgBox("Text not found.")
        End If
    End Sub

    Private Sub ReplaceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ReplaceToolStripMenuItem.Click
        form_replace.ShowDialog()
    End Sub


    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        form_about.ShowDialog()
    End Sub

    Private Sub FontToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FontToolStripMenuItem.Click
        Dim fontdlg As New FontDialog
        If fontdlg.ShowDialog = Windows.Forms.DialogResult.OK Then
            Me.TextBox1.Font = fontdlg.Font
           
        Else

        End If
    End Sub
End Class
