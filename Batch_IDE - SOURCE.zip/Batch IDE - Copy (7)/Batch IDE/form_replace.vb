﻿Public Class form_replace

    Private Sub form_replace_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.BackColor = Color.FromArgb(32, 32, 32)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Not Text_find.Text.Length = 0 Then
            form_main.TextBox1.Text.Replace(Text_find.Text, Text_replace.Text)
            MsgBox("Text replaced", MsgBoxStyle.Information)
        Else
            MsgBox("Could not replace text", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Sub ButtonClose_Click(sender As Object, e As EventArgs) Handles ButtonClose.Click
        Me.Close()
    End Sub
End Class